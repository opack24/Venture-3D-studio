Venture 3D Studio — Mission 3 handoff

Open model.glb in a GLB-compatible viewer or website. project.json is the editable project snapshot. This model is a procedural interpretation of the concept reference, not a scan.

Checksum: SHA-256 366f1ba88efe9c17ec1b6ef402f8a4454cbaea638a90a0ad77e7df02c299bc5c
